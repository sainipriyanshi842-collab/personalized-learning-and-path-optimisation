# Personalized Learning Path Optimization - Phase-II Evaluation Presentation
## Department of Computer Science & Engineering, Graphic Era (Deemed to be University)

### Contents of this package:
1. Phase-II.tex - Main Beamer presentation LaTeX source code (15 complete slides)
2. main.tex - Identical copy to ensure automatic detection in Overleaf
3. graphicera_logo.png - University logo required by the header/title template
4. geulogo.png - Alternate Graphic Era Deemed to be University logo

### How to Compile:
- **On Overleaf:**
  1. Click 'New Project' -> 'Upload Project'
  2. Select this zip file (Phase-2_PPT_LaTeX.zip)
  3. Set Compiler to pdfLaTeX (Default)
  4. Click 'Recompile'
- **On Local LaTeX (MiKTeX / TeX Live / MacTeX):**
  - Run: pdflatex Phase-II.tex (twice for cross-references)

### Project Details Included:
- **Project Title:** Personalized Learning Path Optimization: Dynamic DAG Knowledge Mapping & Dijkstra Adaptive Curriculum Engine
- **Team ID:** DSCPP-III-2026-T284
- **Domain:** AI & Adaptive Educational Systems
- **Faculty Mentor:** Ram ji Chauhan
- **Team Members:**
  1. Priyanshi Saini (2510011893) - Team Lead, Mathematical Optimization Model, DAG & Min-Heap Dijkstra Engine
  2. Ishita Doval (2510012022) - DBMS Relational Schema, ACID Logging, Python Backend Bridge
  3. Navdeep Singh Pundir (2510370386) - OS Concurrency Simulator, Benchmark Datasets & Verification
- **GitHub Repository:** https://github.com/sainipriyanshi842-collab/personalized-learning-and-path-optimisation
- **Empirical Results:** 35.1% study time reduction, 88.5% retention improvement, 9,000+ ops/sec concurrency throughput.
